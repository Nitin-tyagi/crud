import React, { useState} from 'react'
import axios from 'axios';
import { Link, useNavigate } from "react-router-dom";

export const Create = () => {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("");
  const history = useNavigate();
  const header = { "Access-Control-Allow-Origin": "*" };
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("clicked");
    axios.post("https://636cc51891576e19e3149720.mockapi.io/crud-app", {
      name: name,
      email: email,
      header,
    })
.then(()=>{
  history("/read");
})
   
  };
  return (
    <div className='content'>
      <div className='header'>
      <h2>Create</h2>
      <Link to="/read"><button>Show data</button></Link>
      </div>
      <form>
        <table>
          <tbody>
            <tr>
              {/* <th>Create</th> */}
              {/* <th><Link to="/read"><button>Show data</button></Link></th> */}
            </tr>
            <tr>
              <td>Name</td>
              <td>  <input type="text" placeholder='Enter name' onChange={(e) => setName(e.target.value)}></input></td>
            </tr>
            <tr>
              <td>Email</td>
              <td> <input type="email" placeholder='Enter email' onChange={(e) => setEmail(e.target.value)}></input></td>
            </tr>


          
          </tbody>
        </table>

      </form>
      <button type='submit' onClick={handleSubmit}>Submit</button>
    </div>
  )
}
