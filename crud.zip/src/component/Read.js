import axios from 'axios'
import React, { useState, useEffect} from 'react'
import { Link } from 'react-router-dom';


export const Read = () => {
const [data, setData]=useState([]);
function getData(){
  axios.get("https://636cc51891576e19e3149720.mockapi.io/crud-app")
  .then((res)=>{
    console.log(res.data);
    setData(res.data);
  })
}

const handleDelete=(id)=>{
  axios.delete(`https://636cc51891576e19e3149720.mockapi.io/crud-app/${id}`)
  .then(()=>{
    getData();
  })
}

const setToLocalStorage=(id,name,email)=>{
  localStorage.setItem("id", id);
  localStorage.setItem("name", name);
  localStorage.setItem("email", email);
}

useEffect(()=>{
  getData();

},[]);
  return (
    <div className='topnav'>
      <div className='header'>
      <h2>Read Operation</h2>
      <Link to="/"><button>Create data</button></Link>
      </div>
      <table border="2" width="100%">
        <thead><tr>
          <th>Id</th>
          <th>Name</th>
          <th>Email</th>
         
          </tr>
          
        </thead>
        {
          data.map((eachData,index)=>{
            return(
              <>
<tbody>
<tr>
  <td>{eachData.id}</td>
  <td>{eachData.name}</td>
  <td>{eachData.email}</td>
  <td><Link to="/update"><button type='submit'  onClick={()=>setToLocalStorage(
                eachData.id,
                eachData.name,
                eachData.email
            )}>Edit</button></Link></td>
  <td><button type='submit' onClick={()=>{handleDelete(eachData.id)}}>Delete</button></td>
</tr>
        </tbody>
        </>
            )
          })
          }
      </table>
    </div>
  )
}
