import axios from 'axios';
import React, { useEffect, useState } from 'react'
import {Link, useNavigate } from 'react-router-dom';

const Update = () => {
const [id, setId]=useState(0);
const [name,setName]=useState();
const [email, setEmail]=useState();

const Navigate= useNavigate();

useEffect(()=>{
    setId(localStorage.getItem('id'));
    setName(localStorage.getItem("name"));
    setEmail(localStorage.getItem('email'));
},[]);

const handleUpdate = (e)=> {
    e.preventDefault();
    axios
    .put(`https://636cc51891576e19e3149720.mockapi.io/crud-app/${id}`,{
        name:name,
        email: email,
    })
    .then(()=>{
        Navigate("/read")
    })
}

  return (
    <div className='content'> 
        <h2>Update</h2>
         <form>
    <table>
      <tbody>
       
        <tr>
          <td>Name</td>
          <td>  <input type="text" placeholder='Enter name' value={name}  onChange={(e) => setName(e.target.value)}></input></td>
        </tr>
        <tr>
          <td>Email</td>
          <td> <input type="email" placeholder='Enter email' value={email} onChange={(e) => setEmail(e.target.value)}></input></td>
        </tr>


       
      </tbody>
    </table>

  </form>
  <div className='header'>
  <button type='submit' onClick={handleUpdate}>Update</button>
  <Link to="/read"><button>Back</button></Link>
  </div>
  </div>
  )
}

export default Update